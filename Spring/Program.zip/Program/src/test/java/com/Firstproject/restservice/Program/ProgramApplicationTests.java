package com.Firstproject.restservice.Program;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgramApplicationTests {

	@Test
	void contextLoads() {
	}

}
